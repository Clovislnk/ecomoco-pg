import utils
from quart_discord import requires_authorization
from quart import Blueprint, render_template, request, redirect, url_for

app = Blueprint("dashboard", __name__)

@app.route("/dashboard")
@requires_authorization
async def dashboard():
    user = await utils.discord.fetch_user()
    member = await utils.discord.bot_request("/guilds/1258935042785153166/members/" + str(user.id), method="GET")
    if any(any(role == role_to_check for role in member["roles"]) for role_to_check in ["1258935042990801040", "1258935042952921133", "1258935042952921136"]) is False:# officer, cos, tech ops
        return f"You are logged in as @{user.username} and do not have access to the dashboard. <a href={url_for('discord_oauth.oauth_logout')}>Logout</a> and try again if you think this is a mistake.", 403

    homepage_data = await utils.mongo.db.homepage.find_one({})
    return await render_template("dashboard.jinja2", data=homepage_data)

@app.route("/dashboard", methods=["POST"])
@requires_authorization
async def dashboard_edit():
    user = await utils.discord.fetch_user()
    member = await utils.discord.bot_request("/guilds/1258935042785153166/members/" + str(user.id), method="GET")
    if any(any(role == role_to_check for role in member["roles"]) for role_to_check in ["1258935042990801040", "1258935042952921133", "1258935042952921136"]) is False:# officer, cos, tech ops
        return f"You are logged in as @{user.username} and do not have access to the dashboard. <a href={url_for('discord_oauth.oauth_logout')}>Logout</a> and try again if you think this is a mistake.", 403

    form_data = (await request.form).to_dict()
    mongo_data = {}

    if form_data["announcement_text"] != "" and len(form_data["announcement_text"]) <= 500:
        mongo_data["announcement"] = form_data["announcement_text"]

    if form_data["chapters"] != "" and form_data["chapters"].isdigit():
        mongo_data["chapters"] = str(form_data["chapters"])

    if form_data["volunteers"] != "" and form_data["volunteers"].isdigit():
        mongo_data["volunteers"] = str(form_data["volunteers"])

    if form_data["student_projects"] != "" and form_data["student_projects"].isdigit():
        mongo_data["student_projects"] = str(form_data["student_projects"])

    if form_data["people_impacted"] != "" and form_data["people_impacted"].isdigit():
        mongo_data["people_impacted"] = str(form_data["people_impacted"])

    await utils.mongo.db.homepage.update_one({}, {"$set": mongo_data}, upsert=True)
    await utils.cache_data()
    return redirect(url_for("dashboard.dashboard") + "?success=true")



@app.errorhandler(500)
async def internal_server_error(e):
    return redirect(url_for("dashboard.dashboard") + "?success=false")
