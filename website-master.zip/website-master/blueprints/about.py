import utils
from quart import Blueprint, render_template

app = Blueprint("about", __name__, template_folder="../templates/about", url_prefix="/about")

@app.route("/")
async def about_homepage():
    return await render_template("main-info.jinja2")

@app.route("/hq-team")
async def headquarters_about():
    return await render_template("hq-team.jinja2", leadership_list=utils.hq_leadership, dept_list=utils.department_list)

@app.route("/national-leadership")
async def national_leadership_about():
    return await render_template("national-leadership.jinja2", leadership_list=utils.national_leadership)
