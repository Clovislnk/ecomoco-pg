from quart import Blueprint, send_from_directory, Response

app = Blueprint("static", __name__, static_folder="../static")

@app.route("/license")
async def license_file_download():
    return await send_from_directory(".", "LICENSE")

@app.route("/license.txt")
async def license_file_read():
    return Response(open("LICENSE"), mimetype='text/plain')

@app.route("/robots")
@app.route("/robots.txt")
async def robots_file():
    return await app.send_static_file("robots.txt")

@app.route("/sitemap")
@app.route("/sitemap.xml")
async def sitemap_file():
    return await app.send_static_file("sitemap.xml")
