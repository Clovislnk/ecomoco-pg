import utils
from quart import Blueprint, redirect, url_for
from quart_discord import AccessDenied

app = Blueprint("discord_oauth", __name__)

@app.route("/oauth-login")
async def oauth_login():
    return await utils.discord.create_session(scope=["identify"], prompt=False)

@app.route("/oauth-callback")
async def oauth_callback():
    try:
        await utils.discord.callback()
    except AccessDenied:# User clicked "Deny" on the OAuth2 page
        return redirect(url_for("homepage"))
    return redirect(url_for("dashboard.dashboard"))

@app.route("/oauth-logout")
async def oauth_logout():
    utils.discord.revoke()
    return redirect(url_for("homepage"))
